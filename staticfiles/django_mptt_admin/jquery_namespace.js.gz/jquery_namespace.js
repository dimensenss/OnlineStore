window.$ = django.jQuery;
window.jQuery = django.jQuery;
